<style>
#page-wrap {
     width: 800px;
     margin: 0 auto;
}
body {
  text-align: center;
 }

#page-wrap {
  text-align: left;
  width: 800px;
  margin: 0 auto;
}



</style>
<body>
  <div id="page-wrap">
    <!-- all websites HTML here -->
  </div>
</body>